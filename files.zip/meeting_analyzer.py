"""
Meeting Analyzer — Student & Professional Dual Mode
NVIDIA NIM powered analysis
"""

import json
import re
import asyncio
from nvidia_client import NVIDIAClient

SYSTEM_PROMPT = """You are an expert analyst serving both students and working professionals.
Your job is to extract structured, actionable information from transcripts.
Always respond with valid JSON only. No markdown fences, no extra text.
Be specific and use exact words from the transcript where possible.
Support multilingual content — if the transcript is in Hindi, Hinglish, or other languages,
translate key points to English in your response.
"""

SUMMARY_PROMPT = """Analyze this transcript and return a JSON object:

{{
  "executive_summary": "2-3 sentence overview",
  "meeting_type": "lecture / standup / client call / planning / review / study group",
  "main_topics": ["topic1", "topic2", "topic3"],
  "key_discussion_points": [
    {{"point": "concise description", "context": "why it matters", "speaker": "name if known"}}
  ],
  "decisions": [
    {{"decision": "what was decided", "rationale": "why", "decided_by": "who"}}
  ],
  "action_items": [
    {{"task": "specific task", "owner": "person or TBD", "deadline": "date or null", "priority": "high/medium/low"}}
  ],
  "open_questions": ["question or important date mentioned"],
  "risks_concerns": ["risk 1"],
  "sentiment": "positive/neutral/negative/mixed",
  "meeting_effectiveness": "high/medium/low",
  "follow_up_meeting_needed": true,
  "tags": ["tag1", "tag2"],

  "student_notes": {{
    "key_concepts": ["concept 1", "concept 2"],
    "definitions": [{{"term": "word", "definition": "meaning"}}],
    "quiz_questions": ["Q: question? A: answer"],
    "important_dates": ["date or deadline mentioned"],
    "assignments": ["assignment or homework mentioned"],
    "topics_to_study": ["topic to review"]
  }},

  "professional_notes": {{
    "requirements": ["requirement 1", "requirement 2"],
    "requirement_summary": "1 paragraph summary of all requirements discussed",
    "stakeholders": [{{"name": "person", "role": "their role", "responsibility": "what they own"}}],
    "blockers": ["blocker 1"],
    "next_sprint_items": ["item 1"],
    "client_expectations": ["expectation 1"]
  }}
}}

TRANSCRIPT:
{transcript}
"""

SPEAKER_PROMPT = """Analyze speaker contributions and return JSON:

{{
  "speakers": [
    {{
      "name": "Speaker name or Speaker 1",
      "estimated_talk_percentage": 35,
      "key_contributions": ["contribution 1"],
      "role_in_meeting": "facilitator/student/teacher/manager/developer/client",
      "questions_asked": ["question 1"],
      "commitments_made": ["commitment 1"],
      "requirements_given": ["requirement if professional context"]
    }}
  ],
  "meeting_dynamics": "description of how people interacted",
  "dominant_speaker": "name",
  "collaboration_level": "high/medium/low"
}}

TRANSCRIPT:
{transcript}
"""

INSIGHTS_PROMPT = """Provide insights and return JSON:

{{
  "key_insights": ["insight 1", "insight 2"],
  "recommendations": ["recommendation 1"],
  "blockers_identified": ["blocker 1"],
  "success_factors": ["factor 1"],
  "next_steps_summary": "what needs to happen next",

  "for_students": {{
    "study_tips": ["tip based on lecture content"],
    "likely_exam_topics": ["topic that seems important"],
    "connections_to_prior_topics": ["how this connects to previous material"]
  }},

  "for_professionals": {{
    "requirement_gaps": ["unclear or missing requirements"],
    "technical_risks": ["technical risk identified"],
    "suggested_clarifications": ["question to ask before starting work"],
    "definition_of_done": ["criteria for completion if mentioned"]
  }}
}}

TRANSCRIPT:
{transcript}
"""


class MeetingAnalyzer:

    def __init__(self, nvidia_client: NVIDIAClient):
        self.client = nvidia_client

    async def analyze(self, transcript: str, session: dict) -> dict:
        model = (
            "meta/llama-3.1-70b-instruct"
            if len(transcript) > 2000
            else "meta/llama-3.1-8b-instruct"
        )
        max_chars = 12000
        excerpt = transcript[:max_chars]
        if len(transcript) > max_chars:
            excerpt += "\n[Transcript truncated]"

        results = await self._run_all(excerpt, model)
        return self._merge(results, session, transcript)

    async def _run_all(self, transcript: str, model: str) -> dict:
        async def call(prompt_template: str) -> dict:
            prompt = prompt_template.format(transcript=transcript)
            raw = await self.client.chat_complete(
                messages=[
                    {"role": "system", "content": SYSTEM_PROMPT},
                    {"role": "user", "content": prompt},
                ],
                model=model,
                temperature=0.2,
                max_tokens=3500,
            )
            return self._parse_json(raw)

        summary_t  = asyncio.create_task(call(SUMMARY_PROMPT))
        speaker_t  = asyncio.create_task(call(SPEAKER_PROMPT))
        insights_t = asyncio.create_task(call(INSIGHTS_PROMPT))

        summary, speakers, insights = await asyncio.gather(
            summary_t, speaker_t, insights_t, return_exceptions=True
        )

        return {
            "summary":  summary  if not isinstance(summary,  Exception) else {},
            "speakers": speakers if not isinstance(speakers, Exception) else {},
            "insights": insights if not isinstance(insights, Exception) else {},
        }

    def _merge(self, results: dict, session: dict, full_transcript: str) -> dict:
        s = results.get("summary", {})
        sp = results.get("speakers", {})
        ins = results.get("insights", {})
        student = s.get("student_notes", {})
        pro = s.get("professional_notes", {})
        ins_student = ins.get("for_students", {})
        ins_pro = ins.get("for_professionals", {})

        return {
            "executive_summary": s.get("executive_summary", ""),
            "meeting_type": s.get("meeting_type", "General"),
            "main_topics": s.get("main_topics", []),
            "sentiment": s.get("sentiment", "neutral"),
            "meeting_effectiveness": s.get("meeting_effectiveness", "medium"),
            "follow_up_meeting_needed": s.get("follow_up_meeting_needed", False),
            "tags": s.get("tags", []),

            "key_discussion_points": s.get("key_discussion_points", []),
            "decisions": s.get("decisions", []),
            "action_items": s.get("action_items", []),
            "open_questions": s.get("open_questions", []),
            "risks_concerns": s.get("risks_concerns", []),

            "speakers": sp.get("speakers", []),
            "meeting_dynamics": sp.get("meeting_dynamics", ""),
            "dominant_speaker": sp.get("dominant_speaker", ""),
            "collaboration_level": sp.get("collaboration_level", "medium"),

            "key_insights": ins.get("key_insights", []),
            "recommendations": ins.get("recommendations", []),
            "blockers_identified": ins.get("blockers_identified", []),
            "next_steps_summary": ins.get("next_steps_summary", ""),

            # Student-specific
            "key_concepts": student.get("key_concepts", []),
            "definitions": student.get("definitions", []),
            "quiz_questions": student.get("quiz_questions", []),
            "important_dates": student.get("important_dates", []),
            "assignments": student.get("assignments", []),
            "topics_to_study": student.get("topics_to_study", []),
            "study_tips": ins_student.get("study_tips", []),
            "likely_exam_topics": ins_student.get("likely_exam_topics", []),

            # Professional-specific
            "requirements": pro.get("requirements", []),
            "requirement_summary": pro.get("requirement_summary", ""),
            "stakeholders": pro.get("stakeholders", []),
            "client_expectations": pro.get("client_expectations", []),
            "requirement_gaps": ins_pro.get("requirement_gaps", []),
            "technical_risks": ins_pro.get("technical_risks", []),
            "suggested_clarifications": ins_pro.get("suggested_clarifications", []),
            "definition_of_done": ins_pro.get("definition_of_done", []),

            "word_count": len(full_transcript.split()),
            "analyzed_at": __import__("datetime").datetime.utcnow().isoformat(),
        }

    @staticmethod
    def _parse_json(text: str) -> dict:
        text = text.strip()
        text = re.sub(r"^```(?:json)?\s*", "", text)
        text = re.sub(r"\s*```$", "", text)
        try:
            return json.loads(text)
        except json.JSONDecodeError:
            match = re.search(r"\{.*\}", text, re.DOTALL)
            if match:
                try:
                    return json.loads(match.group())
                except Exception:
                    pass
        return {}
