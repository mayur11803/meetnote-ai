# MeetNote AI 🎙

> Smart meeting intelligence for students and working professionals.
> Never miss a requirement. Never lose a lecture note.
> Powered by NVIDIA NIM APIs.

## What it does

**For Students:**
- Transcribes lectures in any language (English, Hindi, Hinglish, etc.)
- Extracts key concepts, definitions, important dates
- Generates quiz questions from lecture content
- Creates study notes and to-do list

**For Professionals:**
- Captures all meeting requirements with zero misunderstanding
- Extracts action items with owner and deadline
- Summarizes decisions made
- Flags blockers and suggests clarification questions
- Perfect for developer-manager-client meetings

## Quick Start

```bash
# 1. Activate venv
venv\Scripts\activate

# 2. Add your NVIDIA API key to .env
NVIDIA_API_KEY=nvapi-your-key-here

# 3. Start backend (Terminal 1)
uvicorn Main:app --reload --port 8000

# 4. Start frontend (Terminal 2)
streamlit run app.py
```

Open http://localhost:8501

## Deploy on Streamlit Cloud

1. Push this folder to GitHub
2. Go to share.streamlit.io
3. New app → select repo → main file: `app.py`
4. Add secret: `NVIDIA_API_KEY = "nvapi-your-key"`
5. Deploy!

## Tech Stack

| Layer | Technology |
|---|---|
| Frontend | Streamlit |
| Backend | FastAPI + Uvicorn |
| Speech-to-Text | NVIDIA Parakeet ASR NIM |
| AI Analysis | NVIDIA Llama 3.1 70B NIM |
| PDF | ReportLab |
| Languages | English, Hindi, Hinglish, and more |
