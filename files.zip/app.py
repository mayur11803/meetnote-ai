"""
MeetNote AI — Smart Meeting & Lecture Intelligence
For Students and Working Professionals
Powered by NVIDIA NIM APIs
"""

import os
import io
import time
import json
import uuid
import base64
import asyncio
import requests
import tempfile
import streamlit as st
from datetime import datetime
from pathlib import Path

# ── Page config ───────────────────────────────────────────────────────────────
st.set_page_config(
    page_title="MeetNote AI",
    page_icon="🎙",
    layout="wide",
    initial_sidebar_state="expanded",
)

API_URL = os.getenv("BACKEND_URL", "http://localhost:8000")
NVIDIA_API_KEY = os.getenv("NVIDIA_API_KEY", "")

# ── Custom CSS ────────────────────────────────────────────────────────────────
st.markdown("""
<style>
@import url('https://fonts.googleapis.com/css2?family=Syne:wght@400;600;700;800&family=DM+Sans:wght@300;400;500&display=swap');

html, body, [class*="css"] { font-family: 'DM Sans', sans-serif; }

.stApp { background: #0D0F14; }

.hero {
    background: linear-gradient(135deg, #0D0F14 0%, #111520 100%);
    border: 1px solid #1E2435;
    border-radius: 16px;
    padding: 2.5rem 2rem 2rem;
    margin-bottom: 1.5rem;
    position: relative;
    overflow: hidden;
}
.hero::before {
    content: '';
    position: absolute;
    top: -60px; right: -60px;
    width: 220px; height: 220px;
    background: radial-gradient(circle, rgba(99,102,241,0.15) 0%, transparent 70%);
    border-radius: 50%;
}
.hero-badge {
    display: inline-block;
    background: rgba(99,102,241,0.15);
    border: 1px solid rgba(99,102,241,0.3);
    color: #A5B4FC;
    padding: 4px 14px;
    border-radius: 20px;
    font-size: 11px;
    font-weight: 500;
    letter-spacing: .06em;
    text-transform: uppercase;
    margin-bottom: 12px;
}
.hero h1 {
    font-family: 'Syne', sans-serif;
    font-size: 2.2rem;
    font-weight: 800;
    color: #F0F2FF;
    margin: 0 0 8px;
    line-height: 1.15;
}
.hero h1 span { color: #818CF8; }
.hero p { color: #6B7280; font-size: 14px; margin: 0; }

.mode-card {
    background: #111520;
    border: 1px solid #1E2435;
    border-radius: 12px;
    padding: 1.2rem;
    cursor: pointer;
    transition: all .2s;
    text-align: center;
    margin-bottom: 8px;
}
.mode-card:hover { border-color: #4F46E5; background: #141828; }
.mode-card.active { border-color: #6366F1; background: rgba(99,102,241,0.08); }
.mode-icon { font-size: 1.8rem; margin-bottom: 6px; }
.mode-title { font-family: 'Syne', sans-serif; font-size: 13px; font-weight: 700; color: #E0E4FF; }
.mode-sub { font-size: 11px; color: #4B5563; margin-top: 2px; }

.stat-card {
    background: #111520;
    border: 1px solid #1E2435;
    border-radius: 10px;
    padding: 1rem;
    text-align: center;
}
.stat-num { font-family: 'Syne', sans-serif; font-size: 1.8rem; font-weight: 800; color: #818CF8; }
.stat-label { font-size: 11px; color: #4B5563; margin-top: 2px; text-transform: uppercase; letter-spacing: .05em; }

.section-title {
    font-family: 'Syne', sans-serif;
    font-size: 13px;
    font-weight: 700;
    color: #6366F1;
    text-transform: uppercase;
    letter-spacing: .08em;
    margin: 1.2rem 0 .6rem;
}

.transcript-box {
    background: #0A0C12;
    border: 1px solid #1E2435;
    border-radius: 10px;
    padding: 1rem;
    height: 280px;
    overflow-y: auto;
    font-family: 'DM Sans', sans-serif;
    font-size: 13px;
    color: #9CA3AF;
    line-height: 1.7;
}

.status-pill {
    display: inline-block;
    padding: 3px 12px;
    border-radius: 20px;
    font-size: 11px;
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: .05em;
}
.status-recording { background: rgba(239,68,68,0.15); color: #FCA5A5; border: 1px solid rgba(239,68,68,0.3); }
.status-processing { background: rgba(245,158,11,0.15); color: #FCD34D; border: 1px solid rgba(245,158,11,0.3); }
.status-completed { background: rgba(16,185,129,0.15); color: #6EE7B7; border: 1px solid rgba(16,185,129,0.3); }
.status-idle { background: rgba(107,114,128,0.15); color: #9CA3AF; border: 1px solid rgba(107,114,128,0.3); }

.insight-card {
    background: #0A0C12;
    border-left: 3px solid #6366F1;
    border-radius: 0 8px 8px 0;
    padding: 10px 14px;
    margin-bottom: 8px;
    font-size: 13px;
    color: #D1D5DB;
    line-height: 1.6;
}
.action-item {
    background: #0A0C12;
    border: 1px solid #1E2435;
    border-radius: 8px;
    padding: 10px 14px;
    margin-bottom: 6px;
    display: flex;
    gap: 10px;
    align-items: flex-start;
}
.action-dot { width: 8px; height: 8px; border-radius: 50%; background: #6366F1; flex-shrink: 0; margin-top: 5px; }
.action-text { font-size: 13px; color: #D1D5DB; flex: 1; line-height: 1.5; }
.action-meta { font-size: 11px; color: #4B5563; margin-top: 3px; }

.concept-tag {
    display: inline-block;
    background: rgba(99,102,241,0.1);
    border: 1px solid rgba(99,102,241,0.2);
    color: #A5B4FC;
    padding: 3px 10px;
    border-radius: 6px;
    font-size: 12px;
    margin: 3px;
}
.deadline-item {
    background: rgba(245,158,11,0.08);
    border: 1px solid rgba(245,158,11,0.2);
    border-radius: 8px;
    padding: 8px 12px;
    margin-bottom: 6px;
    font-size: 13px;
    color: #FCD34D;
}

/* Streamlit overrides */
.stButton > button {
    background: #4F46E5 !important;
    color: white !important;
    border: none !important;
    border-radius: 8px !important;
    font-family: 'DM Sans', sans-serif !important;
    font-weight: 500 !important;
    padding: 0.5rem 1.5rem !important;
}
.stButton > button:hover { background: #4338CA !important; }
.stTextInput > div > div > input,
.stTextArea > div > div > textarea,
.stSelectbox > div > div {
    background: #111520 !important;
    border: 1px solid #1E2435 !important;
    color: #E0E4FF !important;
    border-radius: 8px !important;
}
.stFileUploader { background: #111520 !important; border: 1px dashed #1E2435 !important; border-radius: 10px !important; }
[data-testid="stSidebar"] { background: #0A0C12 !important; border-right: 1px solid #1E2435 !important; }
.stTabs [data-baseweb="tab"] { color: #6B7280 !important; }
.stTabs [aria-selected="true"] { color: #818CF8 !important; border-bottom-color: #6366F1 !important; }
hr { border-color: #1E2435 !important; }
</style>
""", unsafe_allow_html=True)


# ── Hero header ───────────────────────────────────────────────────────────────
st.markdown("""
<div class="hero">
    <div class="hero-badge">⚡ Powered by NVIDIA NIM</div>
    <h1>MeetNote <span>AI</span></h1>
    <p>Smart intelligence for students &amp; professionals — capture every word, never miss a requirement</p>
</div>
""", unsafe_allow_html=True)


# ── Session state ─────────────────────────────────────────────────────────────
for k, v in {
    "session_id": None,
    "recording": False,
    "transcript": "",
    "status": "idle",
    "analysis": None,
    "mode": "student",
    "report_ready": False,
}.items():
    if k not in st.session_state:
        st.session_state[k] = v


# ── Sidebar ───────────────────────────────────────────────────────────────────
with st.sidebar:
    st.markdown('<div class="section-title">Mode</div>', unsafe_allow_html=True)

    col1, col2 = st.columns(2)
    with col1:
        if st.button("🎓 Student", use_container_width=True):
            st.session_state.mode = "student"
    with col2:
        if st.button("💼 Professional", use_container_width=True):
            st.session_state.mode = "professional"

    mode_color = "#6366F1" if st.session_state.mode == "student" else "#10B981"
    mode_label = "Student Mode — Lectures & Study Groups" if st.session_state.mode == "student" else "Professional Mode — Meetings & Requirements"
    st.markdown(f'<div style="background:rgba(99,102,241,0.1);border:1px solid rgba(99,102,241,0.2);border-radius:8px;padding:8px 12px;font-size:12px;color:#A5B4FC;margin-bottom:1rem">{mode_label}</div>', unsafe_allow_html=True)

    st.markdown('<div class="section-title">Session Info</div>', unsafe_allow_html=True)
    title = st.text_input("Title", placeholder="e.g. Physics Lecture / Sprint Planning")
    participants = st.text_area("Participants (one per line)", placeholder="Prof. Sharma\nRahul\nAnanya", height=80)
    language = st.selectbox("Language", ["English", "Hindi + English (Hinglish)", "Hindi", "Marathi + English", "Tamil + English", "Multiple / Auto-detect"])

    st.markdown('<div class="section-title">AI Model</div>', unsafe_allow_html=True)
    model = st.selectbox("NVIDIA NIM Model", [
        "meta/llama-3.1-70b-instruct",
        "meta/llama-3.1-8b-instruct",
        "mistralai/mixtral-8x7b-instruct-v0.1",
    ])

    st.divider()
    # Backend status
    try:
        r = requests.get(f"{API_URL}/health", timeout=2)
        st.markdown('<div style="font-size:12px;color:#6EE7B7">● Backend connected</div>', unsafe_allow_html=True)
    except:
        st.markdown('<div style="font-size:12px;color:#FCA5A5">● Backend offline — start uvicorn first</div>', unsafe_allow_html=True)


# ── Main tabs ─────────────────────────────────────────────────────────────────
tab1, tab2, tab3 = st.tabs(["📁 Upload & Analyze", "🎙 Live Recording", "📄 Report & Insights"])


# ══ TAB 1: Upload ═════════════════════════════════════════════════════════════
with tab1:
    st.markdown('<div class="section-title">Upload Audio File</div>', unsafe_allow_html=True)
    st.markdown('<p style="font-size:13px;color:#6B7280;margin-bottom:1rem">Upload a recorded lecture, meeting or call — supports WAV, MP3, M4A</p>', unsafe_allow_html=True)

    uploaded = st.file_uploader("", type=["wav", "mp3", "m4a", "ogg", "flac"], label_visibility="collapsed")

    if uploaded:
        st.markdown(f'<div style="background:#111520;border:1px solid #1E2435;border-radius:8px;padding:10px 14px;font-size:13px;color:#A5B4FC;margin-bottom:1rem">📎 {uploaded.name} — {round(len(uploaded.getvalue())/1024/1024, 2)} MB</div>', unsafe_allow_html=True)

    col_a, col_b = st.columns([2, 1])
    with col_a:
        analyze_btn = st.button("🚀 Transcribe & Analyze", type="primary", use_container_width=True, disabled=not uploaded or not title)
    with col_b:
        if not title:
            st.markdown('<div style="font-size:12px;color:#EF4444;padding:8px 0">← Enter title in sidebar first</div>', unsafe_allow_html=True)

    if analyze_btn and uploaded and title:
        plist = [p.strip() for p in participants.split("\n") if p.strip()]

        with st.status("Step 1/3 — Creating session...", expanded=True) as status:
            try:
                r = requests.post(f"{API_URL}/sessions/create", json={
                    "meeting_title": title,
                    "participants": plist,
                    "language": language,
                })
                sid = r.json()["session_id"]
                st.session_state.session_id = sid
                requests.post(f"{API_URL}/sessions/{sid}/start")
                st.write("✅ Session created")

                status.update(label="Step 2/3 — Transcribing with NVIDIA Parakeet ASR...")
                files = {"audio_file": (uploaded.name, uploaded.getvalue(), "audio/wav")}
                r = requests.post(f"{API_URL}/transcribe/chunk", params={"session_id": sid}, files=files)
                transcript_text = r.json().get("chunk", {}).get("text", "")
                st.session_state.transcript = transcript_text
                requests.post(f"{API_URL}/sessions/{sid}/stop")
                st.write("✅ Transcription complete")

                status.update(label="Step 3/3 — NVIDIA AI analyzing content...")
                for _ in range(40):
                    r = requests.get(f"{API_URL}/sessions/{sid}/status")
                    s = r.json().get("status", "")
                    st.session_state.status = s
                    if s == "completed":
                        # Load analysis
                        r2 = requests.get(f"{API_URL}/sessions/{sid}/analysis")
                        st.session_state.analysis = r2.json().get("analysis", {})
                        st.session_state.report_ready = True
                        break
                    elif s == "failed":
                        break
                    time.sleep(3)

                status.update(label="✅ Analysis complete!", state="complete")
                st.success("Done! Go to the **Report & Insights** tab to see your results.")

            except Exception as e:
                st.error(f"Error: {e}")

    # Show transcript preview
    if st.session_state.transcript:
        st.markdown('<div class="section-title">Transcript Preview</div>', unsafe_allow_html=True)
        preview = st.session_state.transcript[:800] + ("..." if len(st.session_state.transcript) > 800 else "")
        st.markdown(f'<div class="transcript-box">{preview}</div>', unsafe_allow_html=True)


# ══ TAB 2: Live Recording ═════════════════════════════════════════════════════
with tab2:
    st.markdown('<div class="section-title">Live Recording</div>', unsafe_allow_html=True)

    # Status display
    status_map = {
        "idle": ("idle", "Ready to record"),
        "recording": ("recording", "🔴 Recording in progress"),
        "processing": ("processing", "⚙ Processing..."),
        "completed": ("completed", "✅ Complete"),
    }
    s_class, s_text = status_map.get(st.session_state.status, ("idle", "Ready"))
    st.markdown(f'<span class="status-pill status-{s_class}">{s_text}</span>', unsafe_allow_html=True)

    st.markdown("")
    col1, col2, col3 = st.columns(3)

    with col1:
        start_btn = st.button("▶ Start Recording", use_container_width=True,
                              disabled=st.session_state.recording or not title)
    with col2:
        stop_btn = st.button("⏹ Stop & Analyze", use_container_width=True,
                             disabled=not st.session_state.recording)
    with col3:
        if st.session_state.session_id:
            st.markdown(f'<div style="font-size:11px;color:#4B5563;padding:8px 0">Session: {st.session_state.session_id[:8]}...</div>', unsafe_allow_html=True)

    if start_btn and title:
        plist = [p.strip() for p in participants.split("\n") if p.strip()]
        try:
            r = requests.post(f"{API_URL}/sessions/create", json={
                "meeting_title": title, "participants": plist, "language": language
            })
            sid = r.json()["session_id"]
            st.session_state.session_id = sid
            st.session_state.recording = True
            st.session_state.status = "recording"
            st.session_state.transcript = ""
            st.session_state.report_ready = False
            requests.post(f"{API_URL}/sessions/{sid}/start")
            st.rerun()
        except Exception as e:
            st.error(f"Could not start: {e}")

    if stop_btn and st.session_state.session_id:
        try:
            requests.post(f"{API_URL}/sessions/{st.session_state.session_id}/stop")
            st.session_state.recording = False
            st.session_state.status = "processing"
            st.rerun()
        except Exception as e:
            st.error(f"Could not stop: {e}")

    # Live transcript
    st.markdown('<div class="section-title">Live Transcript</div>', unsafe_allow_html=True)
    if st.session_state.recording:
        if st.button("🔄 Refresh"):
            try:
                r = requests.get(f"{API_URL}/sessions/{st.session_state.session_id}/transcript")
                st.session_state.transcript = r.json().get("transcript", "")
            except:
                pass

    transcript_display = st.session_state.transcript or "<span style='color:#374151;font-style:italic'>Transcript will appear here as people speak...</span>"
    st.markdown(f'<div class="transcript-box">{transcript_display}</div>', unsafe_allow_html=True)

    # Setup reminder
    st.markdown("""
    <div style="background:rgba(99,102,241,0.05);border:1px solid rgba(99,102,241,0.15);border-radius:10px;padding:14px;margin-top:1rem">
        <div style="font-size:12px;font-weight:600;color:#818CF8;margin-bottom:6px">📋 Before your meeting — VB-Cable Setup</div>
        <div style="font-size:12px;color:#6B7280;line-height:1.7">
        1. Install VB-Cable from <strong style="color:#9CA3AF">vb-audio.com/Cable</strong><br>
        2. Set CABLE Input as default Windows playback device<br>
        3. Now all meeting audio (Google Meet/Zoom/Teams) gets captured
        </div>
    </div>
    """, unsafe_allow_html=True)


# ══ TAB 3: Report & Insights ══════════════════════════════════════════════════
with tab3:
    if not st.session_state.report_ready and not st.session_state.analysis:
        st.markdown("""
        <div style="text-align:center;padding:3rem 1rem;color:#374151">
            <div style="font-size:3rem;margin-bottom:1rem">📄</div>
            <div style="font-family:'Syne',sans-serif;font-size:16px;color:#6B7280">No report yet — upload an audio file or use live recording first</div>
        </div>
        """, unsafe_allow_html=True)
    else:
        analysis = st.session_state.analysis or {}

        # ── Stats row ────────────────────────────────────────────────────────
        c1, c2, c3, c4 = st.columns(4)
        with c1:
            st.markdown(f'<div class="stat-card"><div class="stat-num">{len(analysis.get("action_items", []))}</div><div class="stat-label">Action Items</div></div>', unsafe_allow_html=True)
        with c2:
            st.markdown(f'<div class="stat-card"><div class="stat-num">{len(analysis.get("key_discussion_points", []))}</div><div class="stat-label">Key Points</div></div>', unsafe_allow_html=True)
        with c3:
            st.markdown(f'<div class="stat-card"><div class="stat-num">{len(analysis.get("decisions", []))}</div><div class="stat-label">Decisions</div></div>', unsafe_allow_html=True)
        with c4:
            wc = analysis.get("word_count", 0)
            st.markdown(f'<div class="stat-card"><div class="stat-num">{wc}</div><div class="stat-label">Words</div></div>', unsafe_allow_html=True)

        # ── Summary ──────────────────────────────────────────────────────────
        summary = analysis.get("executive_summary", "")
        if summary:
            st.markdown('<div class="section-title">Summary</div>', unsafe_allow_html=True)
            st.markdown(f'<div style="background:#0A0C12;border:1px solid #1E2435;border-radius:10px;padding:14px;font-size:14px;color:#D1D5DB;line-height:1.7">{summary}</div>', unsafe_allow_html=True)

        # ── Mode-specific sections ────────────────────────────────────────────
        if st.session_state.mode == "student":

            # Key concepts
            topics = analysis.get("main_topics", [])
            if topics:
                st.markdown('<div class="section-title">Key Concepts</div>', unsafe_allow_html=True)
                tags_html = "".join(f'<span class="concept-tag">{t}</span>' for t in topics)
                st.markdown(f'<div style="margin-bottom:1rem">{tags_html}</div>', unsafe_allow_html=True)

            # Key discussion points = lecture notes
            points = analysis.get("key_discussion_points", [])
            if points:
                st.markdown('<div class="section-title">Lecture Notes</div>', unsafe_allow_html=True)
                for pt in points:
                    p = pt.get("point", str(pt)) if isinstance(pt, dict) else str(pt)
                    ctx = pt.get("context", "") if isinstance(pt, dict) else ""
                    st.markdown(f'<div class="insight-card"><strong>{p}</strong>{"<br><span style=\'color:#6B7280;font-size:12px\'>" + ctx + "</span>" if ctx else ""}</div>', unsafe_allow_html=True)

            # Action items = to-do list / assignments
            actions = analysis.get("action_items", [])
            if actions:
                st.markdown('<div class="section-title">To-Do / Assignments</div>', unsafe_allow_html=True)
                for item in actions:
                    task = item.get("task", str(item)) if isinstance(item, dict) else str(item)
                    deadline = item.get("deadline", "") if isinstance(item, dict) else ""
                    priority = item.get("priority", "medium") if isinstance(item, dict) else "medium"
                    p_color = {"high": "#FCA5A5", "medium": "#FCD34D", "low": "#6EE7B7"}.get(priority, "#9CA3AF")
                    st.markdown(f'''<div class="action-item">
                        <div class="action-dot"></div>
                        <div class="action-text">{task}
                            <div class="action-meta">
                                {"📅 " + deadline if deadline else ""}
                                <span style="color:{p_color};margin-left:8px">{priority.upper()}</span>
                            </div>
                        </div>
                    </div>''', unsafe_allow_html=True)

            # Important dates
            open_q = analysis.get("open_questions", [])
            if open_q:
                st.markdown('<div class="section-title">Important Questions / Dates</div>', unsafe_allow_html=True)
                for q in open_q:
                    st.markdown(f'<div class="deadline-item">📅 {q}</div>', unsafe_allow_html=True)

            # Insights as quiz hints
            insights = analysis.get("key_insights", [])
            if insights:
                st.markdown('<div class="section-title">Study Insights</div>', unsafe_allow_html=True)
                for ins in insights:
                    st.markdown(f'<div class="insight-card">💡 {ins}</div>', unsafe_allow_html=True)

        else:  # Professional mode

            # Requirements
            points = analysis.get("key_discussion_points", [])
            if points:
                st.markdown('<div class="section-title">Requirements Discussed</div>', unsafe_allow_html=True)
                for pt in points:
                    p = pt.get("point", str(pt)) if isinstance(pt, dict) else str(pt)
                    ctx = pt.get("context", "") if isinstance(pt, dict) else ""
                    spk = pt.get("speaker", "") if isinstance(pt, dict) else ""
                    st.markdown(f'<div class="insight-card"><strong>{p}</strong>{"<br><span style=\'color:#6B7280;font-size:12px\'>" + ctx + "</span>" if ctx else ""}{"<br><span style=\'color:#6366F1;font-size:12px\'>— " + spk + "</span>" if spk else ""}</div>', unsafe_allow_html=True)

            # Decisions
            decisions = analysis.get("decisions", [])
            if decisions:
                st.markdown('<div class="section-title">Decisions Made</div>', unsafe_allow_html=True)
                for d in decisions:
                    dec = d.get("decision", str(d)) if isinstance(d, dict) else str(d)
                    rat = d.get("rationale", "") if isinstance(d, dict) else ""
                    st.markdown(f'<div class="insight-card">✅ <strong>{dec}</strong>{"<br><span style=\'color:#6B7280;font-size:12px\'>" + rat + "</span>" if rat else ""}</div>', unsafe_allow_html=True)

            # Action items with owner
            actions = analysis.get("action_items", [])
            if actions:
                st.markdown('<div class="section-title">Action Items & Responsibilities</div>', unsafe_allow_html=True)
                for item in actions:
                    task = item.get("task", str(item)) if isinstance(item, dict) else str(item)
                    owner = item.get("owner", "TBD") if isinstance(item, dict) else "TBD"
                    deadline = item.get("deadline", "") if isinstance(item, dict) else ""
                    priority = item.get("priority", "medium") if isinstance(item, dict) else "medium"
                    p_color = {"high": "#FCA5A5", "medium": "#FCD34D", "low": "#6EE7B7"}.get(priority, "#9CA3AF")
                    st.markdown(f'''<div class="action-item">
                        <div class="action-dot"></div>
                        <div class="action-text">{task}
                            <div class="action-meta">
                                👤 <strong style="color:#9CA3AF">{owner}</strong>
                                {"· 📅 " + deadline if deadline else ""}
                                <span style="color:{p_color};margin-left:8px">{priority.upper()}</span>
                            </div>
                        </div>
                    </div>''', unsafe_allow_html=True)

            # Recommendations for developers / team
            recs = analysis.get("recommendations", [])
            if recs:
                st.markdown('<div class="section-title">Recommendations</div>', unsafe_allow_html=True)
                for r in recs:
                    st.markdown(f'<div class="insight-card">→ {r}</div>', unsafe_allow_html=True)

            # Blockers
            blockers = analysis.get("blockers_identified", [])
            if blockers:
                st.markdown('<div class="section-title">Blockers / Risks</div>', unsafe_allow_html=True)
                for b in blockers:
                    st.markdown(f'<div style="background:rgba(239,68,68,0.08);border:1px solid rgba(239,68,68,0.2);border-radius:8px;padding:10px 14px;margin-bottom:6px;font-size:13px;color:#FCA5A5">⚠ {b}</div>', unsafe_allow_html=True)

        st.divider()

        # ── Download PDF ──────────────────────────────────────────────────────
        st.markdown('<div class="section-title">Download Report</div>', unsafe_allow_html=True)
        col_dl, col_regen = st.columns([2, 1])

        with col_dl:
            if st.session_state.session_id:
                try:
                    pdf_r = requests.get(f"{API_URL}/report/{st.session_state.session_id}")
                    if pdf_r.status_code == 200:
                        st.download_button(
                            label="⬇ Download PDF Report",
                            data=pdf_r.content,
                            file_name=f"meetnote_{title.replace(' ','_')[:20]}_{datetime.now().strftime('%Y%m%d')}.pdf",
                            mime="application/pdf",
                            use_container_width=True,
                        )
                    else:
                        st.warning("Report still generating... refresh in a moment.")
                except Exception as e:
                    st.error(f"Could not fetch report: {e}")

        with col_regen:
            if st.button("🔄 Regenerate", use_container_width=True):
                if st.session_state.session_id:
                    requests.post(f"{API_URL}/report/{st.session_state.session_id}/generate")
                    st.info("Regenerating...")
